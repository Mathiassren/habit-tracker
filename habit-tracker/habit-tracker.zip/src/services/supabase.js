export { supabase } from "./supabase/browser";
