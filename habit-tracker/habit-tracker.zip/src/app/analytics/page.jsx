"use client";

import HabitAnalytics from "@/app/components/HabitAnalytics";

export default function AnalyticsPage() {
  return (
    <div className="p-8">
      <HabitAnalytics />
    </div>
  );
}
