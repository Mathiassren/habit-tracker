"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import { supabase } from "@/services/supabase";
import dayjs from "dayjs";
import isoWeek from "dayjs/plugin/isoWeek";
dayjs.extend(isoWeek);

// Recharts mini charts
// Recharts mini charts
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  Tooltip,
  XAxis, // ✅ add
  YAxis, // ✅ add
} from "recharts";

/* ------------------------------- Utilities ------------------------------- */

const toISO = (d) =>
  (d instanceof Date ? d : new Date(d)).toLocaleDateString("en-CA");

const startOfYearISO = (y) => `${y}-01-01`;
const endOfYearISO = (y) => `${y}-12-31`;

const daysInMonth = (y, m0) => new Date(y, m0 + 1, 0).getDate();

function rangeDays(startISO, endISO) {
  const out = [];
  const d = dayjs(startISO);
  const end = dayjs(endISO);
  for (let cur = d; !cur.isAfter(end); cur = cur.add(1, "day")) {
    out.push(cur.format("YYYY-MM-DD"));
  }
  return out;
}

function computeStreaks(sortedDaysAsc, todayISO) {
  // sortedDaysAsc: unique ISO dates with >=1 completion
  if (!sortedDaysAsc.length) return { current: 0, longest: 0 };
  let longest = 0;
  let cur = 0;

  let prev = null;
  for (const d of sortedDaysAsc) {
    if (!prev) {
      cur = 1;
      longest = Math.max(longest, cur);
      prev = d;
      continue;
    }
    const diff = dayjs(d).diff(dayjs(prev), "day");
    if (diff === 1) {
      cur += 1;
    } else if (diff > 1) {
      cur = 1;
    }
    longest = Math.max(longest, cur);
    prev = d;
  }

  // current streak must run up to yesterday or today
  const last = sortedDaysAsc[sortedDaysAsc.length - 1];
  const gap = dayjs(toISO(todayISO)).diff(dayjs(last), "day");
  const current = gap === 0 || gap === 1 ? cur : 0;

  return { current, longest };
}

function donutPercent(value, max = 100) {
  const pct = Math.max(0, Math.min(100, Math.round((value / max) * 100)));
  const r = 18;
  const c = 2 * Math.PI * r;
  const dash = (pct / 100) * c;
  return { c, dash, r, pct };
}

/* ----------------------------- Calendar (left) ---------------------------- */

function MiniMonth({
  month, // dayjs of any day in the month
  highlighted = new Set(), // ISO dates to highlight
  onChangeMonth,
  onPickDate,
}) {
  const y = month.year();
  const m0 = month.month(); // 0..11
  const first = dayjs(new Date(y, m0, 1));
  const last = dayjs(new Date(y, m0, daysInMonth(y, m0)));
  const startGrid = first.startOf("week"); // Sunday start (like screenshot)
  const endGrid = last.endOf("week");

  const weeks = [];
  let cur = startGrid;
  while (cur.isBefore(endGrid) || cur.isSame(endGrid, "day")) {
    const row = [];
    for (let i = 0; i < 7; i++) {
      const iso = cur.format("YYYY-MM-DD");
      const inMonth = cur.month() === m0;
      row.push({ iso, day: cur.date(), inMonth, hit: highlighted.has(iso) });
      cur = cur.add(1, "day");
    }
    weeks.push(row);
  }

  return (
    <div className="w-full max-w-xs">
      <div className="flex items-center justify-between mb-2 text-sm text-gray-300">
        <button
          className="px-2 py-1 rounded hover:bg-gray-800"
          onClick={() => onChangeMonth(month.subtract(1, "month"))}
        >
          &lt;
        </button>
        <div className="font-semibold">{month.format("MMMM YYYY")}</div>
        <button
          className="px-2 py-1 rounded hover:bg-gray-800"
          onClick={() => onChangeMonth(month.add(1, "month"))}
        >
          &gt;
        </button>
      </div>

      <div className="grid grid-cols-7 text-xs text-gray-500 mb-1">
        {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => (
          <div key={d} className="text-center py-1">
            {d}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {weeks.flat().map((c) => (
          <button
            key={c.iso}
            onClick={() => c.inMonth && onPickDate?.(c.iso)}
            className={`relative h-9 rounded-md text-sm
              ${c.inMonth ? "text-gray-200 hover:bg-gray-800" : "text-gray-600"}
            `}
          >
            {c.day}
            {c.hit && (
              <span
                className="absolute left-1/2 -translate-x-1/2 bottom-1 w-2 h-2 rounded-full"
                style={{ backgroundColor: "#ff9db0" }}
              />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------ Sparkline UI ------------------------------ */

function TinyArea({ data = [] }) {
  const chartData = data.length ? data : [{ x: "", y: 0 }];

  return (
    <div className="w-full h-24">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={chartData}
          margin={{ top: 4, right: 4, left: 0, bottom: 0 }}
        >
          <XAxis dataKey="x" hide />
          <YAxis hide domain={[0, "dataMax"]} />
          <Tooltip
            contentStyle={{
              background: "#111",
              border: "1px solid #333",
              borderRadius: 8,
              color: "#fff",
              padding: "6px 8px",
            }}
            formatter={(v) => [`${v} day${v === 1 ? "" : "s"}`, "Completed"]}
            labelFormatter={() => ""}
          />
          <Area
            type="monotone"
            dataKey="y"
            stroke="#ff8aa1"
            fill="#ff8aa133"
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

/* --------------------------- Main Analytics Card -------------------------- */

export default function HabitAnalytics({ title = "Analytics" }) {
  const [month, setMonth] = useState(dayjs()); // selected month
  const [loading, setLoading] = useState(true);
  const [byDay, setByDay] = useState({}); // { 'YYYY-MM-DD': count }
  const [uniqueDays, setUniqueDays] = useState(new Set()); // Set of days with >=1
  const [year, setYear] = useState(new Date().getFullYear());

  const todayISO = useMemo(() => toISO(new Date()), []);
  const yearRange = useMemo(() => {
    const y = new Date().getFullYear();
    return { since: startOfYearISO(y), until: endOfYearISO(y) };
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        setByDay({});
        setUniqueDays(new Set());
        setLoading(false);
        return;
      }

      // Prefer completed_on; fallback to completed_at in range
      let { data, error } = await supabase
        .from("habit_completions")
        .select("completed_on, completed_at")
        .eq("user_id", user.id)
        .gte("completed_on", yearRange.since)
        .lte("completed_on", yearRange.until);

      let rows = data || [];
      if (error || !Array.isArray(rows)) {
        const start = new Date(`${yearRange.since}T00:00:00`).toISOString();
        const end = new Date(`${yearRange.until}T23:59:59.999`).toISOString();
        const res2 = await supabase
          .from("habit_completions")
          .select("completed_at")
          .eq("user_id", user.id)
          .gte("completed_at", start)
          .lte("completed_at", end);
        rows = res2.data || [];
      }

      const map = {};
      for (const r of rows) {
        const iso = r.completed_on ? r.completed_on : toISO(r.completed_at);
        map[iso] = (map[iso] || 0) + 1;
      }
      setByDay(map);
      setUniqueDays(new Set(Object.keys(map)));
      setYear(new Date().getFullYear());
    } finally {
      setLoading(false);
    }
  }, [yearRange.since, yearRange.until]);

  useEffect(() => {
    load();
    // live updates if you like (optional)
    const ch = supabase
      .channel("analytics-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "habit_completions" },
        load
      )
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [load]);

  /* ----------------------------- Derived metrics ---------------------------- */

  const {
    monthDays,
    monthCompletedDays,
    monthConsistencyPct,
    monthSpark,
    yearSpark,
    weekCompletedDays,
    yearCompletedDays,
    overallRatePct,
    streaks,
  } = useMemo(() => {
    const y = month.year();
    const m0 = month.month();

    const mdays = daysInMonth(y, m0);
    const allMonthDays = rangeDays(
      `${y}-${String(m0 + 1).padStart(2, "0")}-01`,
      `${y}-${String(m0 + 1).padStart(2, "0")}-${String(mdays).padStart(
        2,
        "0"
      )}`
    );

    const completedMonth = allMonthDays.filter((d) => (byDay[d] || 0) > 0);
    const monthConsistency = Math.round(
      (completedMonth.length / allMonthDays.length) * 100
    );

    // Current week (ISO)
    const weekStart = dayjs().startOf("isoWeek").format("YYYY-MM-DD");
    const weekEnd = dayjs().endOf("isoWeek").format("YYYY-MM-DD");
    const weekRange = rangeDays(weekStart, weekEnd);
    const weekCompleted = weekRange.filter((d) => (byDay[d] || 0) > 0);

    // Year unique days
    const yStart = startOfYearISO(year);
    const yEnd = endOfYearISO(year);
    const yRange = rangeDays(yStart, yEnd);
    const yCompleted = yRange.filter((d) => (byDay[d] || 0) > 0);

    // Streaks (use sorted unique days ascending)
    const sortedUnique = yCompleted.slice(); // already sorted by rangeDays
    const st = computeStreaks(sortedUnique, todayISO);

    // Sparklines (sum per day)
    const makeSpark = (daysArr) =>
      daysArr.map((iso) => ({ x: iso, y: byDay[iso] || 0 }));

    const monthSparkline = makeSpark(allMonthDays);
    const yearSparkline = makeSpark(yRange);

    const elapsedDays = dayjs(todayISO).diff(dayjs(yStart), "day") + 1;
    const overallRate = Math.round((yCompleted.length / elapsedDays) * 100);

    return {
      monthDays: mdays,
      monthCompletedDays: completedMonth.length,
      monthConsistencyPct: monthConsistency,
      monthSpark: monthSparkline,
      yearSpark: yearSparkline,
      weekCompletedDays: weekCompleted.length,
      yearCompletedDays: yCompleted.length,
      overallRatePct: overallRate,
      streaks: st,
    };
  }, [byDay, month, todayISO, year]);

  const monthHighlightSet = useMemo(() => {
    const y = month.year();
    const m0 = month.month();
    const mdays = daysInMonth(y, m0);
    const all = rangeDays(
      `${y}-${String(m0 + 1).padStart(2, "0")}-01`,
      `${y}-${String(m0 + 1).padStart(2, "0")}-${String(mdays).padStart(
        2,
        "0"
      )}`
    );
    return new Set(all.filter((d) => (byDay[d] || 0) > 0));
  }, [byDay, month]);

  /* --------------------------------- UI ----------------------------------- */

  if (loading) return null;

  const donutMonth = donutPercent(monthConsistencyPct, 100);
  const donutOverall = donutPercent(overallRatePct, 100);

  return (
    <section className="w-full text-gray-100">
      {/* Top stripe hint like your screenshot */}
      <div className="text-sm text-gray-300 mb-4">
        <span className="opacity-75">{yearCompletedDays}</span> completions in{" "}
        {year}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[280px,1fr] gap-8">
        {/* Left column: title + month calendar */}
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <span
              className="inline-block w-3 h-3 rounded-sm"
              style={{ backgroundColor: "#ff9db0" }}
            />
            <h2 className="font-play text-3xl font-extrabold tracking-wide">
              qweqwewe
            </h2>
          </div>

          <div>
            <h3 className="text-sm font-mono text-gray-300 mb-2">
              Selected time frame
            </h3>
            <MiniMonth
              month={month}
              highlighted={monthHighlightSet}
              onChangeMonth={setMonth}
              onPickDate={() => {}}
            />
          </div>
        </div>

        {/* Right column: analytics cards */}
        <div className="space-y-6">
          <h3 className="font-mono text-lg text-gray-300">Analytics</h3>

          <div className="grid md:grid-cols-3 gap-5">
            {/* Current streak */}
            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5">
              <div className="text-4xl font-extrabold">
                {streaks.current}
                <span className="text-sm font-normal ml-1">Days</span>
              </div>
              <div className="text-sm text-gray-400 mt-1">Current Streak</div>
            </div>

            {/* Longest streak */}
            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5">
              <div className="text-4xl font-extrabold">
                {streaks.longest}
                <span className="text-sm font-normal ml-1">Days</span>
              </div>
              <div className="text-sm text-gray-400 mt-1">Longest Streak</div>
            </div>

            {/* Completed in YEAR + sparkline */}
            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5">
              <div className="text-4xl font-extrabold">
                {yearCompletedDays}
                <span className="text-sm font-normal ml-1">Days</span>
              </div>
              <div className="text-sm text-gray-400 mt-1">
                Completed in {year}
              </div>
              <div className="mt-3">
                <TinyArea data={yearSpark} />
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-5">
            {/* Monthly consistency donut */}
            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5 flex items-center gap-4">
              <svg width="54" height="54" viewBox="0 0 54 54">
                <circle
                  cx="27"
                  cy="27"
                  r={donutMonth.r}
                  stroke="#222"
                  strokeWidth="6"
                  fill="none"
                />
                <circle
                  cx="27"
                  cy="27"
                  r={donutMonth.r}
                  stroke="#ff8aa1"
                  strokeWidth="6"
                  strokeDasharray={`${donutMonth.dash} ${donutMonth.c}`}
                  strokeLinecap="round"
                  fill="none"
                  transform="rotate(-90 27 27)"
                />
              </svg>
              <div>
                <div className="text-3xl font-extrabold">
                  {monthConsistencyPct}
                  <span className="text-sm font-normal">%</span>
                </div>
                <div className="text-sm text-gray-400">Monthly Consistency</div>
              </div>
            </div>

            {/* Completed this week */}
            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5">
              <div className="text-4xl font-extrabold">
                {weekCompletedDays}
                <span className="text-sm font-normal ml-1">Days</span>
              </div>
              <div className="text-sm text-gray-400 mt-1">
                Completed this week
              </div>
            </div>

            {/* Completed in selected month + sparkline */}
            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5">
              <div className="text-4xl font-extrabold">
                {monthCompletedDays}
                <span className="text-sm font-normal ml-1">Days</span>
              </div>
              <div className="text-sm text-gray-400 mt-1">
                Completed in {month.format("MMMM")}
              </div>
              <div className="mt-3">
                <TinyArea data={monthSpark} />
              </div>
            </div>
          </div>

          <h3 className="font-mono text-lg text-gray-300">Reports</h3>

          <div className="grid md:grid-cols-3 gap-5">
            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5">
              <div className="text-4xl font-extrabold">
                {monthCompletedDays}
                <span className="text-sm font-normal ml-1">Days</span>
              </div>
              <div className="text-sm text-gray-400 mt-1">
                in {month.format("MMMM")}
              </div>
            </div>

            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5">
              <div className="text-4xl font-extrabold">
                {yearCompletedDays}
                <span className="text-sm font-normal ml-1">Days</span>
              </div>
              <div className="text-sm text-gray-400 mt-1">in Total</div>
            </div>

            <div className="rounded-2xl bg-[#0b0b0f] border border-gray-800 p-5 flex items-center gap-4">
              <svg width="54" height="54" viewBox="0 0 54 54">
                <circle
                  cx="27"
                  cy="27"
                  r={donutOverall.r}
                  stroke="#222"
                  strokeWidth="6"
                  fill="none"
                />
                <circle
                  cx="27"
                  cy="27"
                  r={donutOverall.r}
                  stroke="#ff8aa1"
                  strokeWidth="6"
                  strokeDasharray={`${donutOverall.dash} ${donutOverall.c}`}
                  strokeLinecap="round"
                  fill="none"
                  transform="rotate(-90 27 27)"
                />
              </svg>
              <div>
                <div className="text-3xl font-extrabold">
                  {overallRatePct}
                  <span className="text-sm font-normal">%</span>
                </div>
                <div className="text-sm text-gray-400">Overall Rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
