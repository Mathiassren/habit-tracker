const withPWA = require("next-pwa")({
  dest: "public",
  register: true,
  skipWaiting: true,
});

module.exports = withPWA({
  reactStrictMode: true,
});
// This configuration enables PWA support in the Next.js application
// and sets the public directory for service worker files.
