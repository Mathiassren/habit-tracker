"use client";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/services/supabase";

export function useHeatmap(userId, sinceDate, untilDate, tz = "UTC") {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const since = sinceDate; // 'YYYY-MM-DD'
  const until = untilDate; // 'YYYY-MM-DD'

  useEffect(() => {
    if (!userId || !since || !until) {
      setRows([]);
      setLoading(false);
      return;
    }
    let cancelled = false;

    (async () => {
      setLoading(true);
      const { data, error } = await supabase.rpc("get_heatmap", {
        _uid: userId,
        _since: since,
        _until: until,
        _tz: tz,
      });
      if (!cancelled) {
        if (error) {
          console.error(error);
          setRows([]);
        } else setRows(data || []);
        setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [userId, since, until, tz]);

  const byDate = useMemo(() => {
    const m = {};
    for (const r of rows) m[r.day] = r.cnt;
    return m;
  }, [rows]);

  const total = useMemo(() => rows.reduce((a, r) => a + r.cnt, 0), [rows]);

  return { byDate, total, loading };
}
