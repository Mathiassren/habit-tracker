import TaskBoard from "../components/TaskBoard";

export default function WorkbenchPage() {
  return <TaskBoard />;
}
