"use client";

import { useAuth } from "@/hooks/useAuth";
import { useHeatmap } from "@/hooks/useHeatmap";
import { useStreaks } from "@/hooks/useStreaks";
import HabitHeatmap from "@/app/components/HabitHeatmap";
import { useMemo } from "react";
import Link from "next/link";
import {
  ChartBarIcon as DocumentChartBarIcon,
  AdjustmentsHorizontalIcon,
  HomeIcon,
} from "@heroicons/react/24/outline";

export default function HeatmapPage() {
  const { user, loading } = useAuth();

  // compute date range once per mount/year
  const { since, today, tz, year } = useMemo(() => {
    const y = new Date().getFullYear();
    return {
      since: `${y}-01-01`,
      today: new Date().toISOString().slice(0, 10),
      tz: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
      year: y,
    };
  }, []);

  // ✅ Call hooks on every render (no conditional calls)
  const { byDate, total } = useHeatmap(user?.id, since, today, tz);
  const { current_streak, longest_streak } = useStreaks(user?.id, tz);

  if (loading || !user) return null;

  return (
    <div className="p-8 space-y-6">
      <h1 className="font-play font-bold text-xl">Analyze</h1>
      <h2 className="text-lg font-play text-gray-300">
        Welcome, {user?.user_metadata?.full_name?.split(" ")[0] || "Guest"}!
      </h2>

      <HabitHeatmap byDate={byDate} />

      <div className="text-sm text-gray-300">
        {total} completion{total === 1 ? "" : "s"} in {year}
      </div>

      <section className="rounded-2xl bg-gray-900/70 border border-gray-800 p-6">
        <h3 className="font-play font-bold text-lg mb-3">
          Habit Stats{" "}
          <span className="ml-2 text-xs px-2 py-0.5 rounded-full bg-purple-800/40 text-purple-300">
            Beta
          </span>
        </h3>
        <div className="grid sm:grid-cols-3 gap-4">
          <Stat label="Current streak" value={`${current_streak}d`} />
          <Stat label="Longest streak" value={`${longest_streak}d`} />
          <Stat label="Total completions" value={total} />
        </div>
      </section>

      <section className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4">
        <Link href="/">
          <div className="bg-gray-800 w-36 h-36 rounded-lg items-center flex flex-col justify-center">
            <HomeIcon className="w-10 h-10 mb-1 text-gray-400" />
            Home
          </div>
        </Link>
        <Link href="/dailylog">
          <div className="bg-gray-800 w-36 h-36 rounded-lg items-center flex flex-col justify-center">
            <DocumentChartBarIcon className="w-10 h-10 mb-1 text-gray-400" />
            Daily Log
          </div>
        </Link>
        <Link href="/preferences">
          <div className="bg-gray-800 w-36 h-36 rounded-lg items-center flex flex-col justify-center">
            <AdjustmentsHorizontalIcon className="w-10 h-10 mb-1 text-gray-400" />
            Preferences
          </div>
        </Link>
      </section>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-xl bg-gray-900 border border-gray-800 p-4">
      <div className="text-gray-400 text-xs">{label}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
    </div>
  );
}
